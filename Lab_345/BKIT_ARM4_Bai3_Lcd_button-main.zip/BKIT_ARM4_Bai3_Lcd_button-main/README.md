## BKIT ARM 4 - LAB 03: Khảo sát LCD TOUCH và Button

- Biết cách cấu hình và sử dụng timer trên kit thí nghiệm;
- Biết cách cấu hình và sử dụng thư viện LED bảy đoạn trên kit thí nghiệm;

## Hướng dẫn Build, Run

- Bước 1: Import Project vào STM32CubeIDE (File -> Open Projects From File System...);
- Bước 2: Build project;
- Bước 3: Run;