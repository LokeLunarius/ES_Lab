/*
 * picture.h
 *
 *  Created on: Oct 30, 2023
 *      Author: phamv
 */

#ifndef INC_PICTURE_H_
#define INC_PICTURE_H_

extern const unsigned char gImage_logo[16200];

extern const unsigned char gImage_pic[86400];
#endif /* INC_PICTURE_H_ */
